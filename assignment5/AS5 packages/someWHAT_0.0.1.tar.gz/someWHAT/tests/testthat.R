library(testthat)
library(someWHAT)

test_check("someWHAT")
